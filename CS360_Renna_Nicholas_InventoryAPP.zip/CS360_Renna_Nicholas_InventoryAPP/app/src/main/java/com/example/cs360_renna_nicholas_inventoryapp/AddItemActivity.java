package com.example.cs360_renna_nicholas_inventoryapp;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
//Add inventory screen logic
////Author: Nicholas Renna
////SNHU CS-360 Mobile Programming Project final
public class AddItemActivity extends AppCompatActivity {
    EditText item_upc, item_descrip, item_qty, item_type;
    Item_DB_Helper ItemDB;
    Button Add_button, home_add_button;




    @Override
    protected void onCreate(Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_item);
        //EditView fields
        item_upc = (EditText) findViewById(R.id.addUPC);
        item_descrip = (EditText) findViewById(R.id.addDescription);
        item_qty = (EditText) findViewById(R.id.addQty);
        item_type = (EditText) findViewById(R.id.addType);
        //Buttons
        Add_button = (Button) findViewById(R.id.Addbutton);
        home_add_button = findViewById(R.id.myInventoryAddButton);
        //Database
        ItemDB = new Item_DB_Helper(this);

        //Button to add inventory
        Add_button.setOnClickListener(view -> {
            InsertItemIntoDatabase();
            Intent intent = new Intent(AddItemActivity.this, ItemListActivity.class);
            startActivity(intent);
        });

        //Home button
        home_add_button.setOnClickListener(view ->{
            Intent intent = new Intent(AddItemActivity.this, ItemListActivity.class);
            startActivity(intent);
        });
    }
    //Public function to add inventory, UPC, Description, Qty and Type
    private void InsertItemIntoDatabase(){
        String upc = item_upc.getText().toString();
        String description = item_descrip.getText().toString();
        String qty = item_qty.getText().toString();
        String type = item_type.getText().toString();
        //calls the database function for CRUD Create
        Item item = new Item(upc, description, qty, type);
        ItemDB.createItem(item);
        //Confirmation message
        Toast.makeText(AddItemActivity.this, "Your inventory items were added!", Toast.LENGTH_LONG).show();
        Intent add = new Intent();
        setResult(RESULT_OK, add);
        this.finish();
    }

}
