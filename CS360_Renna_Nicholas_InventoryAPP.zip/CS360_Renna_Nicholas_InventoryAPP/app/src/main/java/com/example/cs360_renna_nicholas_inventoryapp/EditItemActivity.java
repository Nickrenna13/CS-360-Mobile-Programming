package com.example.cs360_renna_nicholas_inventoryapp;

import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;
//Author: Nicholas Renna
//SNHU CS-360 Mobile Programming Project final
public class EditItemActivity extends AppCompatActivity {



    @Override
    protected void onCreate(Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_edit_item);

    }

}
