package com.example.cs360_renna_nicholas_inventoryapp;

import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
//Author: Nicholas Renna
//SNHU CS-360 Mobile Programming Project final
public class LoginActivity extends AppCompatActivity {

    //Main variable for logging in
    EditText username, password;
    Button login_button, register_button;
    User_DB_Helper UserDB;
    SQLiteDatabase DB;
    String usernameHolder, passwordHolder;
    Boolean EmptyHolder;
    @Override
    protected void onCreate(Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        //Variable for Login
        username = (EditText) findViewById(R.id.LoginEmail);
        password = (EditText) findViewById(R.id.LoginPass);

        //Buttons for Login in
        login_button = (Button) findViewById(R.id.buttonConfirm);
        register_button = (Button) findViewById(R.id.registerButton);

        //DataABse login in
        UserDB = new User_DB_Helper(this);

        //textwacher for register button
        username.addTextChangedListener(textWatcher);
        password.addTextChangedListener(textWatcher);

        //Login Button
        login_button.setOnClickListener(view -> {
            LoginUser();
        });


        //Register Button
        register_button.setOnClickListener(view -> {
            Intent intent = new Intent(LoginActivity.this, RegisterActivity.class);
            startActivity(intent);
        });

    }
    //Login function
    public void LoginUser(){
        String name = username.getText().toString();
        String pass = password.getText().toString();
        boolean validUser = UserDB.checkUsername(name, pass);
        boolean validPass = UserDB.checkUsernamePassword(name, pass);
        //Uses database from User_DB_Login
        if (name.isEmpty() || pass.isEmpty()){
            Toast.makeText(LoginActivity.this, "All fields are required", Toast.LENGTH_SHORT).show();
        } else if (validUser) {
            if (validPass){
                Toast.makeText(this, "Login Successful", Toast.LENGTH_SHORT).show();
                Intent intent = new Intent(LoginActivity.this, ItemListActivity.class);
                startActivity(intent);
            }
        }
        else {
            Toast.makeText(this, "Invalid Credentials", Toast.LENGTH_SHORT).show();
        }
    }

        //Using a textwatcher to hide the register button once the user types into the username field
    private final TextWatcher textWatcher = new TextWatcher() {
        @Override
        public void beforeTextChanged(CharSequence s, int start, int count, int after) {

        }

        @Override
        public void onTextChanged(CharSequence s, int start, int before, int count) {
            String user_Name = username.getText().toString();
            String user_Pass = password.getText().toString();

            register_button.setEnabled(!user_Name.isEmpty() && !user_Pass.isEmpty());

        }

        @Override
        public void afterTextChanged(Editable s) {

        }
    };
}
