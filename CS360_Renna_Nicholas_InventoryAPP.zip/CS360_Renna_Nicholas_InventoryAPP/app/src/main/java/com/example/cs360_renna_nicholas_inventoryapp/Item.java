package com.example.cs360_renna_nicholas_inventoryapp;

public class Item {

    int id;
    String upc;
    String description;
    String qty;
    String type;

    public Item() {
        super();
    }

    //Build 1nd constructor with ID inside
    public Item(int i, String upc, String description, String qty, String type) {
        super();
        this.id = i;
        this.upc = upc;
        this.description = description;
        this.qty = qty;
        this.type = type;
    }

    //Build 2nd constructor
    public Item(String upc, String description, String qty, String type){

        this.upc = upc;
        this.description = description;
        this.qty = qty;
        this.type = type;
    }
    //Getters and setters for inventory application
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getUpc() {
        return upc;
    }

    public void setUpc(String upc) {
        this.upc = upc;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getQty() {
        return qty;
    }

    public void setQty(String qty) {
        this.qty = qty;
    }
    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }


}
