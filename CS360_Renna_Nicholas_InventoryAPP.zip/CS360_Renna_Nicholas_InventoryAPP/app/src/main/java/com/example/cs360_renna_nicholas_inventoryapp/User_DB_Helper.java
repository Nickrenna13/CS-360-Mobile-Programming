package com.example.cs360_renna_nicholas_inventoryapp;

import android.annotation.SuppressLint;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class User_DB_Helper extends SQLiteOpenHelper {
    private static User_DB_Helper user_DB_Helper;
    private static final String DATABASE_NAME = "users.db";
    private static final int DATABASE_VERSION = 1;
    public static final String TABLE_USERS = "users";


    public static final String KEY_ID = "id";
    public static final String KEY_USERNAME = "username";
    public static final String KEY_PASSWORD = "password";

    private static final String CREATE_USERS_TABLE = "CREATE TABLE IF NOT EXISTS " +
            TABLE_USERS + " (" +
            KEY_ID + " INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, " +
            KEY_USERNAME + " VARCHAR, " +
            KEY_PASSWORD + " VARCHAR" + ");";


    public User_DB_Helper(Context context){
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    //table creator for username and passwords
    @Override
    public void onCreate(SQLiteDatabase UserDB){
        UserDB.execSQL(CREATE_USERS_TABLE);
    }

    @Override
    public void onUpgrade(SQLiteDatabase UserDB, int oldVersion, int newVersion){
        UserDB.execSQL("DROP TABLE IF EXISTS " + TABLE_USERS);
        onCreate(UserDB);
    }

    //Adding username and passwords
    public void insertData(User user){
        SQLiteDatabase UserDB = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();

        contentValues.put(KEY_USERNAME, user.getUserName());
        contentValues.put(KEY_PASSWORD, user.getUserPass());

        UserDB.insert(TABLE_USERS, null, contentValues);
        UserDB.close();
    }

    //Check if user name exists
    public Boolean checkUsername(String username, String password){
        SQLiteDatabase UserDB = this.getReadableDatabase();
        Cursor cursor = UserDB.rawQuery("Select * from users where username = ? and password =?",
                new String[]{username, password});
        return (cursor.getCount() > 0) ? true : false;
        //Cursor cursor = UserDB.query(TABLE_USERS, new String[] { KEY_USERNAME, KEY_PASSWORD},
         //       KEY_USERNAME + "=?", new String[] {username}, null, null, null);
    }
    //Check to username and password are a match in the DB
    public Boolean checkUsernamePassword(String username, String password) {
        SQLiteDatabase UserDB = this.getReadableDatabase();
        Cursor cursor = UserDB.rawQuery("Select * from users where username = ? and password =?",
                new String[]{username, password});
        return cursor.getCount() > 0;
    }



}
