package com.example.cs360_renna_nicholas_inventoryapp;


import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;
//Author: Nicholas Renna
//SNHU CS-360 Mobile Programming Project final
public class AlarmBroadcast {
    public static AlertDialog doubleButton(final SmsActivity context){
        AlertDialog.Builder builder = new AlertDialog.Builder(context);
        //Setting title, message and plus and minus
        builder.setTitle(R.string.sms_permission_text)
                .setCancelable(false)
                .setIcon(R.drawable.sms_notification)
                .setMessage(R.string.sms_enable_msg)
                .setNegativeButton(R.string.disable_sms_button, (dialog, arg1) -> {
                    Toast.makeText(context, "SMS Alerts: Disabled", Toast.LENGTH_LONG).show();
                    SmsActivity.DenySendSMS();
                    dialog.cancel();
                })
                .setPositiveButton(R.string.enable_sms_button, (dialog, arg1) -> {
                    Toast.makeText(context, "SMS Alerts: Enabled", Toast.LENGTH_LONG).show();
                    SmsActivity.AllowSendSMS();
                    dialog.cancel();
                });
        return builder.create();

    }
}
