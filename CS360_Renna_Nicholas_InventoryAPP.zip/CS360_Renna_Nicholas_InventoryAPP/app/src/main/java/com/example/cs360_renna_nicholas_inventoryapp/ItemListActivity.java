package com.example.cs360_renna_nicholas_inventoryapp;

import android.content.Intent;
import android.os.Bundle;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;
//Reference: zyBooks
//Author: Nicholas Renna
//SNHU CS-360 Mobile Programming Project final
public class ItemListActivity extends AppCompatActivity {

    CustomAdapter customAdapter;
    Button AddButton, HomeButton, SettingButton, LogoutButton;
    ListView ItemsListView;
    TextView upc, Descrip, Qty, Type, TotalItems;
    Item_DB_Helper ItemDB;
    ArrayList<Item> itemList;
    int itemsCount;




    @Override
    protected void onCreate(Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_item_list);
        //Button variables
        AddButton = (Button) findViewById(R.id.addItemButton);
        HomeButton = (Button) findViewById(R.id.myInventoryButton);
        SettingButton = (Button) findViewById(R.id.settingsButton);
        LogoutButton = (Button) findViewById(R.id.logoutButton);
        //Listview variable
        ItemsListView = (ListView) findViewById(R.id.bodyListView);

        //Textview
        upc = (TextView) findViewById(R.id.itemUPC);
        Descrip = (TextView) findViewById(R.id.itemDescription);
        Qty = (TextView) findViewById(R.id.itemQty);
        Type = (TextView) findViewById(R.id.itemType);
        TotalItems = (TextView) findViewById(R.id.totalItems);


        ItemDB = new Item_DB_Helper(this);
        //gets all items
        itemList = (ArrayList<Item>) ItemDB.getAllItems();



        //gets items count to display
        itemsCount = ItemDB.getItemsCount();
        if (itemsCount > 0) {
            customAdapter = new CustomAdapter(this, itemList, ItemDB);
            ItemsListView.setAdapter(customAdapter);
        } else {
            Toast.makeText(ItemListActivity.this, "Database is Empty", Toast.LENGTH_LONG).show();
        }
        TotalItems.setText(String.valueOf(itemsCount));

        //button  ADD, HOME and SETTING
        AddButton.setOnClickListener(view ->{
            Intent intent = new Intent(ItemListActivity.this, AddItemActivity.class);
            startActivity(intent);
        });
        HomeButton.setOnClickListener(view ->{
            Intent intent = new Intent(ItemListActivity.this, ItemListActivity.class);
            startActivity(intent);
        });
        SettingButton.setOnClickListener(view ->{
            Intent intent = new Intent(ItemListActivity.this, SmsActivity.class);
            startActivity(intent);
        });
        LogoutButton.setOnClickListener(view ->{
            Intent intent = new Intent(ItemListActivity.this, LoginActivity.class);
            startActivity(intent);
            finish();
        });
    }
    //Function to use database and show inventory in activity_item_list, scrollable body
    //This function also shows how many different items are in the inventory
    public void onActivityResult(int requestCode, int resultCode, Intent data){
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == 1){
            if (resultCode == RESULT_OK){
                itemsCount = ItemDB.getItemsCount();
                TotalItems.setText(String.valueOf(itemsCount));
                //Informing the adapter of change
                if (customAdapter == null){
                    customAdapter = new CustomAdapter(this, itemList, ItemDB);
                    ItemsListView.setAdapter(customAdapter);
                }
                //Showing all the inventory
                customAdapter.itemList = (ArrayList<Item>) ItemDB.getAllItems();
                ((BaseAdapter)ItemsListView.getAdapter()).notifyDataSetChanged();
            } else {
                Toast.makeText(ItemListActivity.this, "Action Canceled", Toast.LENGTH_SHORT).show();
            }

        }

    }


}
