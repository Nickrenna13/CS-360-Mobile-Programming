package com.example.cs360_renna_nicholas_inventoryapp;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
//Author: Nicholas Renna
//SNHU CS-360 Mobile Programming Project final
public class RegisterActivity extends AppCompatActivity {
    Button RegisterButton;
    private EditText username, password, repassword;
    User_DB_Helper UserDB;

    @Override
    protected void onCreate(Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);

        //EditText variables
        username = (EditText) findViewById(R.id.EditEmail);
        password = (EditText) findViewById(R.id.editTextPassword);
        repassword = (EditText) findViewById(R.id.confirmPassword);
        //Register button
        RegisterButton = (Button) findViewById(R.id.registerButton);

        UserDB = new User_DB_Helper(this);
        //Set up the register button with variables
        RegisterButton.setOnClickListener(view ->{
            InsertUserIntoDB();
            EmptyEditTextAfterDataInsert();
        });
    }
    //Function for user insert
    public void InsertUserIntoDB(){
        String name = username.getText().toString();
        String pass = password.getText().toString();
        String repass = repassword.getText().toString();

        User user = new User (name, pass);
        UserDB.insertData(user);
        if(name.isEmpty() || (pass.isEmpty() || (repass.isEmpty()))){
            Toast.makeText(RegisterActivity.this, "Check that all fields are filled in", Toast.LENGTH_LONG).show();
        }
        Toast.makeText(this, "User has be registered!", Toast.LENGTH_SHORT).show();
        startActivity(new Intent(RegisterActivity.this, LoginActivity.class));
        this.finish();
    }
    // Empty edittext after done inserting in database
    public void EmptyEditTextAfterDataInsert(){
        username.getText().clear();
        password.getText().clear();
    }


}
