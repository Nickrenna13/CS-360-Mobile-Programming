package com.example.cs360_renna_nicholas_inventoryapp;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
//Reference: zyBooks 5.6SQLite and video: https://www.youtube.com/watch?v=4k1ZMpO9Zn0
//Author: Nicholas Renna
//SNHU CS-360 Mobile Programming Project final
public class Item_DB_Helper extends SQLiteOpenHelper {
    private static final int DATABASE_VERSION = 1;
    private static final String DATABASE_NAME = "ItemsData.db";
    private static final String TABLE_NAME = "ItemsTable";
    private static final String COLUMN_0_ID = "id";
    private static final String COLUMN_1_UPC = "UPC";
    private static final String COLUMN_2_DESCRIPTION = "description";
    private static final String COLUMN_3_QUANTITY = "quantity";
    private static final String COLUMN_4_TYPE = "type";

    private static final String CREATE_ITEMS_TABLE = "CREATE TABLE IF NOT EXISTS " +
            TABLE_NAME + " (" +
            COLUMN_0_ID + " INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, " +
            COLUMN_1_UPC + " VARCHAR, " +
            COLUMN_2_DESCRIPTION + " VARCHAR, " +
            COLUMN_3_QUANTITY + " VARCHAR, " +
            COLUMN_4_TYPE + " VARCHAR" + ");";
    public Item_DB_Helper(Context context){
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase ItemDB) {
        ItemDB.execSQL(CREATE_ITEMS_TABLE);
    }

    @Override
    public void onUpgrade(SQLiteDatabase ItemDB, int oldVersion, int newVersion){
        ItemDB.execSQL("DROP TABLE IF EXISTS " + TABLE_NAME);
        onCreate(ItemDB);
    }

    //CRUD operation for Inventory Items
    //Add item from database
    public void createItem(Item item){
        SQLiteDatabase ItemDB = this.getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put(COLUMN_1_UPC, item.getUpc());
        values.put(COLUMN_2_DESCRIPTION, item.getDescription());
        values.put(COLUMN_3_QUANTITY, item.getQty());
        values.put(COLUMN_4_TYPE, item.getType());

        ItemDB.insert(TABLE_NAME, null, values);

        ItemDB.close();
    }

    //Read items from database
    public Item readItem(int id){
        SQLiteDatabase ItemDB = this.getReadableDatabase();

        Cursor cursor = ItemDB.query(TABLE_NAME,
                new String[] { COLUMN_0_ID, COLUMN_1_UPC, COLUMN_2_DESCRIPTION, COLUMN_3_QUANTITY, COLUMN_4_TYPE }, COLUMN_0_ID + "=?",
                new String[] { String.valueOf(id) }, null, null, null, null);
        if(cursor != null)
            cursor.moveToFirst();

        Item item = new Item(Integer.parseInt(Objects.requireNonNull(cursor).getString(0)),
                cursor.getString(1), cursor.getString(2), cursor.getString(3), cursor.getString(4));

        cursor.close();

        return item;
    }
    //Updating items
    public int updateItem (Item item){
        SQLiteDatabase ItemDB = this.getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put(COLUMN_1_UPC, item.getUpc());
        values.put(COLUMN_2_DESCRIPTION, item.getDescription());
        values.put(COLUMN_3_QUANTITY, item.getQty());
        values.put(COLUMN_4_TYPE, item.getType());

        return ItemDB.update(TABLE_NAME, values, COLUMN_0_ID + " = ?", new String[] { String.valueOf(item.getId()) });
    }
    //Delete Items
    public void deleteItem(Item item){
        SQLiteDatabase ItemDB = this.getWritableDatabase();

        ItemDB.delete(TABLE_NAME, COLUMN_0_ID + " = ?", new String[] { String.valueOf(item.getId()) });
        ItemDB.close();
    }

    //To view all items READ
    public List<Item> getAllItems(){
        List<Item> itemList = new ArrayList<>();
        //Select all of query
        String selectQuery = "SELECT * FROM " + TABLE_NAME;

        SQLiteDatabase ItemDB = this.getWritableDatabase();
        Cursor cursor = ItemDB.rawQuery(selectQuery, null);

        if(cursor.moveToFirst()) {
            do {
                Item item = new Item();
                item.setId(Integer.parseInt(cursor.getString(0)));
                item.setUpc(cursor.getString(1));
                item.setDescription(cursor.getString(2));
                item.setQty(cursor.getString(3));
                item.setType(cursor.getString(4));

                itemList.add(item);
            } while (cursor.moveToNext());
        }
        cursor.close();
        return itemList;
    }
    //check item exists
    public boolean checkItemExists(String itemUpc ) {
        SQLiteDatabase ItemDB = this.getReadableDatabase();
        Cursor cursor = ItemDB.query(TABLE_NAME,
                new String[]{COLUMN_1_UPC},
                COLUMN_1_UPC + "=?",
                new String[]{itemUpc}, null, null, null);
        boolean exists = (cursor.getCount() > 0);
        cursor.close();
        return exists;
    }

    //Item count for qty
    public int getItemsCount() {
        String countQuery = "SELECT * FROM " + TABLE_NAME;
        SQLiteDatabase ItemDB = this.getReadableDatabase();
        Cursor cursor = ItemDB.rawQuery(countQuery, null);
        int itemsTotal = cursor.getCount();
        cursor.close();
        return itemsTotal;
    }

}
