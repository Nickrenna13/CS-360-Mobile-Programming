package com.example.cs360_renna_nicholas_inventoryapp;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import androidx.appcompat.app.AppCompatActivity;
//Start screen or HOME screen. Simple button to move to login screen.
//Author: Nicholas Renna
//SNHU CS-360 Mobile Programming Project final
public class MainActivity extends AppCompatActivity {
    Button button_start;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //Initialize Button
        button_start = findViewById(R.id.buttonHome);

        //moves to next screen: Login
        button_start.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this,
                        LoginActivity.class);
                startActivity(intent);
            }
        });
    }
}