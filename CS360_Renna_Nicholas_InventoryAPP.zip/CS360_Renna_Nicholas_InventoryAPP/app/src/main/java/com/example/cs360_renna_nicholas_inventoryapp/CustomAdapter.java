package com.example.cs360_renna_nicholas_inventoryapp;

import android.app.Activity;
import android.graphics.Color;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.PopupWindow;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;

//Reference: https://developer.android.com/reference/android/widget/BaseAdapter
//Reference: https://developer.android.com/reference/android/widget/PopupWindow
//This allows the Inventory screen to edit inventory with a popup window
// and a delete inventory with image buttons inside the ListView
//Author: Nicholas Renna
//SNHU CS-360 Mobile Programming Project final
public class CustomAdapter extends BaseAdapter {
    private final Activity context;
    private PopupWindow popwindow;
    ArrayList <Item> itemList;
    Item_DB_Helper ItemDB;
    //Build Constructor
    public CustomAdapter(Activity context, ArrayList<Item> itemList, Item_DB_Helper ItemDB){
        this.context = context;
        this.itemList = itemList;
        this.ItemDB = ItemDB;

    }
    //Holds variables
    public static class itemViewHolder {
        TextView textViewItemId, textViewItemUpc, textViewItemDesc, textViewItemQty, textViewItemType;
        ImageButton edit_button, delete_button;
    }

    @Override
    public int getCount() {
        return itemList.size();
    }

    @Override
    public Object getItem(int position) {
        return position;
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        View row = convertView;
        LayoutInflater inflater = context.getLayoutInflater();
        itemViewHolder holder;
        if (convertView == null){
            holder = new itemViewHolder();
            row = inflater.inflate(R.layout.item_row, null, true);

            holder.edit_button = row.findViewById(R.id.editButton);
            holder.textViewItemId = row.findViewById(R.id.textViewItemId);
            holder.textViewItemUpc = row.findViewById(R.id.textViewItemUpc);
            holder.textViewItemDesc = row.findViewById(R.id.textViewItemDesc);
            holder.textViewItemQty = row.findViewById(R.id.textViewItemQty);
            holder.textViewItemType = row.findViewById(R.id.textViewItemType);
            holder.delete_button = row.findViewById(R.id.deleteButton);


            row.setTag(holder);
        } else {
            holder = (itemViewHolder) convertView.getTag();
        }
        holder.textViewItemId.setText("" + itemList.get(position).getId());
        holder.textViewItemUpc.setText(itemList.get(position).getUpc());
        holder.textViewItemDesc.setText(itemList.get(position).getDescription());
        holder.textViewItemQty.setText(itemList.get(position).getQty());
        holder.textViewItemType.setText(itemList.get(position).getType());

        final int positionPopup = position;
        //Delete button inside the ListView for easy access
        holder.delete_button.setOnClickListener(view ->{
            ItemDB.deleteItem(itemList.get(position));
            itemList = (ArrayList<Item>) ItemDB.getAllItems();
            notifyDataSetChanged();
            //Message
            Toast.makeText(context, "Your Item has been deleted", Toast.LENGTH_SHORT).show();
        });
        //edit button inside the ListView for easy access
        holder.edit_button.setOnClickListener(view -> editPopup(positionPopup));
        String itemValue = holder.textViewItemQty.getText().toString();
        //Checking if inventory is zero
        if (itemValue.equals("0")){
            holder.textViewItemId.setBackgroundColor(Color.RED);
            holder.textViewItemQty.setTextColor(Color.WHITE);
            SmsActivity.SendSMSMessage(context.getApplicationContext());
        } else {
            holder.textViewItemQty.setBackgroundColor(Color.parseColor("#E6E6E6"));
            holder.textViewItemQty.setTextColor(Color.BLACK);
        }


        return row;

    }
    //Edit on item per row
    public void editPopup(final int positionPopup){
        LayoutInflater inflater = context.getLayoutInflater();
        View layout = inflater.inflate(R.layout.activity_edit_item, context.findViewById(R.id.popup_element));
        //pop up size
        popwindow = new PopupWindow(layout, 950, 2000, true);
        popwindow.showAtLocation(layout, Gravity.CENTER, 0, 0);

        //Setting up edittext fields
        final EditText editUpc_Item = layout.findViewById(R.id.editUpcItem);
        final EditText editDescription_Item = layout.findViewById(R.id.editDescriptionItem);
        final EditText editQty_Item = layout.findViewById(R.id.editQtyItem);
        final EditText editType_Item = layout.findViewById(R.id.editTypeItem);

        editUpc_Item.setText((itemList.get(positionPopup).getUpc()));
        editDescription_Item.setText((itemList.get(positionPopup).getDescription()));
        editQty_Item.setText((itemList.get(positionPopup).getQty()));
        editType_Item.setText((itemList.get(positionPopup).getType()));

        //Button set up
        Button save = layout.findViewById(R.id.editSave);
        Button cancel = layout.findViewById(R.id.editCancel);
        //save button to save edit information
        save.setOnClickListener(view ->{
            String item_upc = editUpc_Item.getText().toString();
            String item_des = editDescription_Item.getText().toString();
            String item_qty = editQty_Item.getText().toString();
            String item_type = editType_Item.getText().toString();
            //Setters
            Item item = itemList.get(positionPopup);
            item.setUpc(item_upc);
            item.setDescription(item_des);
            item.setQty(item_qty);
            item.setType(item_type);
            ItemDB.updateItem(item);
            itemList = (ArrayList<Item>) ItemDB.getAllItems();
            notifyDataSetChanged();
            Toast.makeText(context, "Item has been updated!", Toast.LENGTH_SHORT).show();
            popwindow.dismiss();
        });
        //Cancel action button
        cancel.setOnClickListener(view ->{
            Toast.makeText(context, "Cancelled", Toast.LENGTH_SHORT).show();
            popwindow.dismiss();
        });

    }

}
