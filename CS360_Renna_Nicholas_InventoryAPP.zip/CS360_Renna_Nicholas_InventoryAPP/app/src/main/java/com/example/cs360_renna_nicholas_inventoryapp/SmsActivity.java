package com.example.cs360_renna_nicholas_inventoryapp;

import android.Manifest;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.util.Log;
import android.widget.Button;
import android.widget.Switch;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import java.util.ArrayList;
import java.util.List;

public class SmsActivity extends AppCompatActivity {

    Button item_home, sms_switch;
    Item_DB_Helper ItemDB;
    AlertDialog AlertDialog = null;
    ArrayList<Item> itemList;
    private static final int PERMISSION_SEND_SMS = 0;
    private static boolean smsAuthorized = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sms);

        item_home = (Button) findViewById(R.id.myInventorySMSButton);
        sms_switch = (Button) findViewById(R.id.switchSMS);

        ItemDB = new Item_DB_Helper(this);

        sms_switch.setOnClickListener(view -> {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS) != PackageManager.PERMISSION_GRANTED) {
                if (ActivityCompat.shouldShowRequestPermissionRationale(this, Manifest.permission.SEND_SMS)) {
                    Toast.makeText(this, "For Inventory level alerts SMS permission is required!", Toast.LENGTH_SHORT).show();
                } else {
                    ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.SEND_SMS}, PERMISSION_SEND_SMS);
                }
            } else {
                Toast.makeText(this, "SMS Permission is Allowed!", Toast.LENGTH_SHORT).show();
            }
            //This will create the dialog for the notifications Alerts
            AlertDialog = AlarmBroadcast.doubleButton(this);
            AlertDialog.show();
        });

        item_home.setOnClickListener(view -> {
            Intent intent = new Intent(SmsActivity.this, ItemListActivity.class);
            startActivity(intent);
        });


    }
    //Two boolean for true and false
    public static void AllowSendSMS() {
        smsAuthorized = true;
    }

    public static void DenySendSMS() {
        smsAuthorized = false;
    }

    //Sends message, granted or denied
    public static void SendSMSMessage(Context context) {
        String phone_number = "555-555-5555";
        String msg = "An item in your inventory is empty (0 remaining).";

        // AlertDialogPermission
        if (smsAuthorized) {
            try {
                SmsManager sms_manager = SmsManager.getDefault();
                sms_manager.sendTextMessage(phone_number, null, msg, null, null);
                Toast.makeText(context, "SMS Sent", Toast.LENGTH_LONG).show();
            } catch (Exception ex) {
                Toast.makeText(context, "Permission Denied", Toast.LENGTH_LONG).show();
                ex.printStackTrace();
            }
        } else {
            Toast.makeText(context, "SMS Alert Disabled", Toast.LENGTH_LONG).show();
        }
    }
}






